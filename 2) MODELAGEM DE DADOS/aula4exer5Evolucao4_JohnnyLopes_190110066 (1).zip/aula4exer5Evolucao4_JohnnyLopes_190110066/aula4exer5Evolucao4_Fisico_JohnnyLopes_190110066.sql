-- -------- < Clínica Médica > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 23/10/2023
-- Autor(es) ..............: Johnny da Ponte Lopes
-- Banco de Dados .........: MySQL
-- Base de Dados (nome) ...: bdClinica
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- Ultimas Alteracoes
--   23/10/2023 => Conversão do modelo lógico para o físico
--
-- ---------------------------------------------------------

CREATE TABLE MEDICO (
    numero int(6) NÃO NULO,
    unidadeFederativa char(2) NÃO NULO,
    nomeCompletoMedico varchar(100) NÃO NULO,
    PRIMARY KEY (numero, unidadeFederativa)
);

CREATE TABLE CONSULTA_atende (
    dataConsulta data NÃO NULO,
    nomeCompletoPaciente varchar(100) NÃO NULO,
    codConsulta int(4) NÃO NULO PRIMARY KEY,
    numero int(6) NÃO NULO,
    unidadeFederativa char(2) NÃO NULO,
    nomeCompletoPaciente varchar(100) NÃO NULO,
    dataNascimento data NÃO NULO
);

CREATE TABLE PACIENTE (
    nomeCompletoPaciente varchar(100) NÃO NULO,
    dataNascimento data NÃO NULO,
    sexo char(1) NÃO NULO,
    cep int(8) NÃO NULO,
    cidade varchar(25) NÃO NULO,
    bairro varchar(25) NÃO NULO,
    logradouro varchar(25) NÃO NULO,
    numero int(3) NÃO NULO,
    complemento varchar(25) NÃO NULO,
    telefone int,
    PRIMARY KEY (nomeCompletoPaciente, dataNascimento)
);

CREATE TABLE RECEITA (
    dataEmissao data NÃO NULO,
    codReceita int(4) NÃO NULO PRIMARY KEY,
    codConsulta int(4) NÃO NULO
);

CREATE TABLE MEDICAMENTO (
    nome varchar(100) NÃO NULO,
    principioAtivo varchar(50) NÃO NULO,
    codMedicamento int(4) NÃO NULO PRIMARY KEY
);

CREATE TABLE ESPECIALIZACAO (
    codEspecialidade int(2) NÃO NULO PRIMARY KEY,
    nomeEspecialidade varchar(50) NÃO NULO
);

CREATE TABLE telefone (
    IdTelefone int NÃO NULO PRIMARY KEY,
    telefone int(11) NÃO NULO
);

CREATE TABLE tem (
    numero int(6) NÃO NULO,
    unidadeFederativa char(2) NÃO NULO,
    codEspecialidade int(2) NÃO NULO
);

CREATE TABLE possui (
    codReceita int(4) NÃO NULO,
    codMedicamento int(4) NÃO NULO
);