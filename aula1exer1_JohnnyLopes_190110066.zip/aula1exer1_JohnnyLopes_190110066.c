#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifdef _WIN32
    #define CLEAR_SCREEN "cls"
#else
    #define CLEAR_SCREEN "clear"
#endif

typedef struct Pessoa{
    char nome[100];
    char cpf[12];
}Pessoa;
typedef struct Carro{
    char modelo[100];
    char placa[100];
    char CPFdono[12];
}Carro;

void menu(){
    printf("------------------======------------------\n");
    printf("1 - Cadastrar Proprietário\n");
    printf("2 - Cadastrar Veículo\n");
    printf("3 - Listar\n");
    printf("4 - Sair\n");
    printf("------------------======------------------\n");

}
int VerificaPessoa(char *cpf){
    FILE *arquivo;
    Pessoa P1;
    
    arquivo = fopen("Pessoa.bin","rb");
    
    if(arquivo != NULL){
        while(!feof(arquivo)){
            fread(&P1,sizeof(Pessoa),1,arquivo);
            if(strcmp(cpf,P1.cpf) == 0){
                fclose(arquivo);
                return 1;
                break;
            }
        }
    }
    fclose(arquivo);
    return 0;   
}
int VerificaVeiculo(char *placa){
    FILE *arquivo;
    Carro C;
    
    arquivo = fopen("carro.bin","rb");

    if(arquivo != NULL){
        while(!feof(arquivo)){
            fread(&C,sizeof(Carro),1,arquivo);
            if(strcmp(placa,C.placa) == 0 ){
                fclose(arquivo);
                return 1;
                break;
            }
        }
    }
    fclose(arquivo);
    return 0;   
}
void cadastrarPessoa(){
    FILE* arquivo;
    Pessoa P;
    arquivo = fopen("Pessoa.bin","ab");
    
    if(arquivo == NULL){
        printf("Erro ao abrir o arquivo !\n");
        return;
    }
    printf("\n------------------======------------------\n");
    printf("Digite o seu nome :\n");
    scanf("%s",P.nome);
    printf("Digite o seu cpf :\n");
    scanf("%s",P.cpf);
    if(VerificaPessoa(P.cpf)== 0){
        fwrite(&P,sizeof(Pessoa),1, arquivo);
        fclose(arquivo);
        system(CLEAR_SCREEN);
        printf("Proprietario cadastrado com sucesso !\n\n");
    }else{
        system(CLEAR_SCREEN);
        printf("CPF ja cadastrado no sistema !\n");
        fclose(arquivo);
    }
}
void cadastrarVeiculo(){
    FILE* arquivo;
    Carro V;
    arquivo = fopen("Carro.bin","ab");
    
    if(arquivo == NULL){
        printf("Erro ao abrir o arquivo !\n");
        return;
    }
    printf("\n------------------======------------------\n");
    printf("Digite o modelo do veículo :\n");
    scanf("%s",V.modelo);
    printf("Digite a placa do veículo :\n");
    scanf("%s",V.placa);
    printf("Digite o cpf do proprietário do veículo :\n");
    scanf("%s",V.CPFdono);

    if(VerificaPessoa(V.CPFdono) == 0){
        system(CLEAR_SCREEN);
        printf("CPF não cadastrado no sistema !\n");
        fclose(arquivo);
    }else{
        if(VerificaVeiculo(V.placa) == 0 ){
            fwrite(&V,sizeof(Carro),1, arquivo);
            fclose(arquivo);
            system(CLEAR_SCREEN);
            printf("Veículo cadastrado com sucesso !\n");
        }else{
            system(CLEAR_SCREEN);
            printf("O veículo já esta cadastrado !\n");
            fclose(arquivo);
        }
    }
}
void listar() {
    FILE* arq_pessoa;
    FILE* arq_carro;
    Pessoa P2;
    Carro C2;

    arq_pessoa = fopen("Pessoa.bin", "rb");
    arq_carro = fopen("Carro.bin", "rb");

    if (arq_pessoa != NULL && arq_carro != NULL) {
        while (fread(&P2, sizeof(Pessoa), 1, arq_pessoa) == 1) {
            printf("------------------PROPRIETÁRIOS------------------\n");
            printf("Nome: %s\n", P2.nome);
            printf("CPF: %s\n", P2.cpf);

            int carrosEncontrados = 0;

            while (fread(&C2, sizeof(Carro), 1, arq_carro) == 1) {
                if (strcmp(P2.cpf, C2.CPFdono) == 0) {
                    if (carrosEncontrados == 0) {
                        printf("------------------VEÍCULOS DE %s------------------\n", P2.nome);
                    }
                    printf("Modelo: %s\n", C2.modelo);
                    printf("Placa: %s\n", C2.placa);
                    carrosEncontrados++;
                }
            }

            fseek(arq_carro, 0, SEEK_SET);

            if (carrosEncontrados == 0) {
                printf("Nenhum veículo encontrado para %s.\n", P2.nome);
            }
        }
    }

    fclose(arq_pessoa);
    fclose(arq_carro);
}

int main(){
    int opcao;
    do
    {
        menu();
        printf("Digite uma opcao :\n");
        scanf("%d",&opcao);
    
        switch (opcao)
        {
        case 1:
            system(CLEAR_SCREEN);
            cadastrarPessoa();
            break;
        case 2:
            system(CLEAR_SCREEN);
            cadastrarVeiculo();
            break;
        case 3:
            system(CLEAR_SCREEN);
            listar();
            break;
        default:
            break;
        }
    } while (opcao != 4);
    
       
    return 0;
}