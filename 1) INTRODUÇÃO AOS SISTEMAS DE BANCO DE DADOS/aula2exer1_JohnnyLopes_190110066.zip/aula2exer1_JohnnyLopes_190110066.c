#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct Pessoa{
    char nome[100];
    long long int cpf;
}Pessoa;
typedef struct Carro{
    char modelo[100];
    char placa[7];
    long long int CPFdono;
}Carro;

void limpa_tela ()
{
    system("cls");
    system("clear");
}
int compararPorCPF(const void *a, const void *b) {
    long long int cpf1 = ((Pessoa *)a)->cpf;
    long long int cpf2 = ((Pessoa *)b)->cpf;

    if (cpf1 < cpf2) return -1;
    if (cpf1 > cpf2) return 1;
    return 0;
}

int compararPorPlaca(const void *a, const void *b) {
    return strcmp(((Carro *)a)->placa, ((Carro *)b)->placa);
}

void organizaArquivoCarro(const char *nomeArquivo) {
    FILE *arquivo;
    Carro *registros = NULL;
    int numRegistros = 0;

    arquivo = fopen(nomeArquivo, "rb");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    Carro temp;
    while (fread(&temp, sizeof(Carro), 1, arquivo) == 1) {
        numRegistros++;
        registros = (Carro *)realloc(registros, numRegistros * sizeof(Carro));
        registros[numRegistros - 1] = temp;
    }

    qsort(registros, numRegistros, sizeof(Carro), compararPorPlaca);

    fclose(arquivo);
    arquivo = fopen(nomeArquivo, "wb");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo para escrita.\n");
        free(registros);
        return;
    }

    fwrite(registros, sizeof(Carro), numRegistros, arquivo);

    fclose(arquivo);
    free(registros);
}

void organizaArquivo(const char *nomeArquivo) {
    FILE* arquivo;
    Pessoa *registros = NULL;
    int numRegistros = 0;

    arquivo = fopen(nomeArquivo, "rb");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    Pessoa temp;
    while (fread(&temp, sizeof(Pessoa), 1, arquivo) == 1) {
        numRegistros++;
        registros = (Pessoa *)realloc(registros, numRegistros * sizeof(Pessoa));
        registros[numRegistros - 1] = temp;
    }

    qsort(registros, numRegistros, sizeof(Pessoa), compararPorCPF);

    fclose(arquivo);
    arquivo = fopen(nomeArquivo, "wb");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo para escrita.\n");
        free(registros);
        return;
    }

    fwrite(registros, sizeof(Pessoa), numRegistros, arquivo);

    fclose(arquivo);
    free(registros);
}

void menu(){
    printf("------------------======------------------\n");
    printf("1 - Cadastrar Proprietário\n");
    printf("2 - Cadastrar Veículo\n");
    printf("3 - Listar\n");
    printf("4 - Sair\n");
    printf("------------------======------------------\n");

}
int VerificaPessoa(long long int cpf){
    FILE *arquivo;
    Pessoa P1;
    
    arquivo = fopen("Pessoa.bin","rb");
    
    if(arquivo != NULL){
        while(!feof(arquivo)){
            fread(&P1,sizeof(Pessoa),1,arquivo);
            if(cpf == P1.cpf){
                fclose(arquivo);
                return 1;
                break;
            }
        }
    }
    fclose(arquivo);
    return 0;   
}
int VerificaVeiculo(char *placa){
    FILE *arquivo;
    Carro C;
    
    arquivo = fopen("carro.bin","rb");

    if(arquivo != NULL){
        while(!feof(arquivo)){
            fread(&C,sizeof(Carro),1,arquivo);
            if(strcmp(placa,C.placa) == 0 ){
                fclose(arquivo);
                return 1;
                break;
            }
        }
    }
    fclose(arquivo);
    return 0;   
}

void cadastrarPessoa(){
    FILE* arquivo;
    Pessoa P;
    arquivo = fopen("Pessoa.bin","ab");
    
    if(arquivo == NULL){
        printf("Erro ao abrir o arquivo !\n");
        return;
    }
    printf("\n------------------======------------------\n");
    printf("Digite o seu nome :\n");
    scanf("%s",P.nome);
    printf("Digite o seu cpf :\n");
    scanf("%lld",&P.cpf);
    if(VerificaPessoa(P.cpf) == 0){
        fwrite(&P,sizeof(Pessoa),1, arquivo);
        fclose(arquivo);
        limpa_tela();
        printf("Proprietario cadastrado com sucesso !\n\n");
    }else{
        limpa_tela();
        printf("CPF ja cadastrado no sistema !\n");
        fclose(arquivo);
    }
    organizaArquivo("Pessoa.bin");
}
void cadastrarVeiculo(){
    FILE* arquivo;
    Carro V;
    arquivo = fopen("Carro.bin","ab");
    
    if(arquivo == NULL){
        printf("Erro ao abrir o arquivo !\n");
        return;
    }
    printf("\n------------------======------------------\n");
    printf("Digite o modelo do veículo :\n");
    scanf("%s",V.modelo);
    printf("Digite a placa do veículo :\n");
    scanf("%s",V.placa);
    printf("Digite o cpf do proprietário do veículo :\n");
    scanf("%lld",&V.CPFdono);

    if(VerificaPessoa(V.CPFdono) == 0){
        limpa_tela();
        printf("CPF não cadastrado no sistema !\n");
        fclose(arquivo);
    }else{
        if(VerificaVeiculo(V.placa) == 0 ){
            fwrite(&V,sizeof(Carro),1, arquivo);
            fclose(arquivo);
            limpa_tela();
            printf("Veículo cadastrado com sucesso !\n");
        }else{
            limpa_tela();
            printf("O veículo já esta cadastrado !\n");
            fclose(arquivo);
        }
    }
    organizaArquivoCarro("Carro.bin");
}
void listar() {
    FILE* arq_pessoa;
    FILE* arq_carro;
    Pessoa P2;
    Carro C2;

    arq_pessoa = fopen("Pessoa.bin", "rb");
    arq_carro = fopen("Carro.bin", "rb");

    if (arq_pessoa != NULL && arq_carro != NULL) {
        while (fread(&P2, sizeof(Pessoa), 1, arq_pessoa) == 1) {
            printf("------------------PROPRIETÁRIOS------------------\n");
            printf("Nome: %s\n", P2.nome);
            printf("CPF: %011lld\n", P2.cpf);

            int carrosEncontrados = 0;

            while (fread(&C2, sizeof(Carro), 1, arq_carro) == 1) {
                if (P2.cpf == C2.CPFdono) {
                    if (carrosEncontrados == 0) {
                        printf("------------------VEÍCULOS DE %s------------------\n", P2.nome);
                    }
                    printf("Modelo: %s\n", C2.modelo);
                    printf("Placa: %s\n", C2.placa);
                    printf("------------------======------------------\n");
                    carrosEncontrados++;
                }
            }

            fseek(arq_carro, 0, SEEK_SET);

            if (carrosEncontrados == 0) {
                printf("Nenhum veículo encontrado para %s.\n", P2.nome);
            }
        }
    }

    fclose(arq_pessoa);
    fclose(arq_carro);
}

int main(){
    int opcao;
    do
    {
        menu();
        printf("Digite uma opcao :\n");
        scanf("%d",&opcao);
    
        switch (opcao)
        {
        case 1:
            limpa_tela();
            cadastrarPessoa();
            break;
        case 2:
            limpa_tela();
            cadastrarVeiculo();
            break;
        case 3:
            limpa_tela();
            listar();
            break;
        default:
            break;
        }
    } while (opcao != 4);
    
       
    return 0;
}